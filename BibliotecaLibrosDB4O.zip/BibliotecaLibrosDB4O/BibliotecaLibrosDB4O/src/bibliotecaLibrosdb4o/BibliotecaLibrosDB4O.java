package bibliotecaLibrosdb4o;

import bibliotecalibrosdb4o.model.Libro;
import bibliotecalibrosdb4o.model.Autor;
import bibliotecalibrosdb4o.model.Biblioteca;
import bibliotecalibrosdb4o.model.Usuario;
import bibliotecalibrosdb4o.controller.DatabaseController;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class BibliotecaLibrosDB4O {
    public static void main(String[] args) {
        // 📌 Crear libros
        Libro libro1 = new Libro("Cien años de soledad", 1967);
        Libro libro2 = new Libro("1984", 1949);

        // 📌 Crear autores    
        List<String> librosGarciaMarquez = new ArrayList<>(Arrays.asList("Cien años de soledad", "El amor en los tiempos del cólera", "Crónica de una muerte anunciada"));
        List<String> librosOrwell = new ArrayList<>(Arrays.asList("1984", "Rebelión en la granja", "Homenaje a Cataluña"));
        List<String> librosDoyle = new ArrayList<>(Arrays.asList("Estudio en escarlata", "El signo de los cuatro", "El sabueso de los Baskerville"));

        Autor autor1 = new Autor("Gabriel García Márquez", "gabo@gmail.com", librosGarciaMarquez);
        Autor autor2 = new Autor("George Orwell", "orwell@gmail.com", librosOrwell);
        Autor autor3 = new Autor("Arthur Conan Doyle", "doyle@gmail.com", librosDoyle);

        // 📌 Crear biblioteca y agregar libros
        Biblioteca biblioteca = new Biblioteca("Biblioteca Central");
        biblioteca.agregarLibro(libro1);
        biblioteca.agregarLibro(libro2);

        // 📌 Crear usuario
        List<Biblioteca> bibliotecas = new ArrayList<>();
        bibliotecas.add(biblioteca);
        Usuario usuario = new Usuario("Carlos", "carlos@email.com", bibliotecas);

        // 📌 Guardar en la base de datos
        System.err.println("\nGuardar autores:");
        DatabaseController.guardarAutor(autor1);
        DatabaseController.guardarAutor(autor2);
        DatabaseController.guardarAutor(autor3);

        System.err.println("\nGuardar libros:");
        DatabaseController.guardarLibro(libro1);
        DatabaseController.guardarLibro(libro2);

        System.err.println("\nGuardar biblioteca:");
        DatabaseController.guardarBiblioteca(biblioteca);

        System.err.println("\nGuardar usuario:");
        DatabaseController.guardarUsuario(usuario);

        // 📌 Listar información
        System.err.println("\nListar libros:");
        DatabaseController.listarLibros();

        System.err.println("\nListar autores:");
        DatabaseController.listarAutores();

        System.err.println("\nListar bibliotecas:");
        DatabaseController.listarBibliotecas();

        System.err.println("\nListar usuarios:");
        DatabaseController.listarUsuarios();

        // 📌 Operaciones adicionales
        System.err.println("\nBuscar libros por autor: Gabriel García Márquez");
        DatabaseController.buscarPorAutor("Gabriel García Márquez");

        System.err.println("\nActualizar el título de un libro");
        DatabaseController.actualizarLibro("1984", "Mil novecientos ochenta y cuatro");

        System.err.println("\nEliminar libro: Cien años de soledad");
        DatabaseController.eliminarLibro("Cien años de soledad");

        System.err.println("\nListar libros después de la eliminación:");
        DatabaseController.listarLibros();

        // 📌 Agregar un libro a la biblioteca existente
        System.err.println("\nAgregar otro libro a la biblioteca existente: Biblioteca Central");
        Libro libro3 = new Libro("El principito", 1943);
        DatabaseController.agregarLibroABiblioteca("Biblioteca Central", libro3);

        // Verificar que la biblioteca se actualizó correctamente
        DatabaseController.listarBibliotecas();
    }
}
