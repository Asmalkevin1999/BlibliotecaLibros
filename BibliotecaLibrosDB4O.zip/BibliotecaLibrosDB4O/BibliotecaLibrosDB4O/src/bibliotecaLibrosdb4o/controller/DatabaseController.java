/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
bibliotecaLibrosdb4o;

import biblioteca.model.*;
import com.db4o.*;
import com.db4o.query.Query;
import java.util.List;

public class DatabaseController {
    private static final String DB_FILE = "biblioteca.db4o";
    private static ObjectContainer db = null;

    private static void abrirDB() {
        if (db == null || db.ext().isClosed()) {
            db = Db4oEmbedded.openFile(DB_FILE);
        }
    }
    
    public static void cerrarDB() {
        if (db != null) {
            db.close();
            db = null;
            System.out.println("📚 Base de datos cerrada correctamente.");
        }
    }

    // Guardar libro
    public static void guardarLibro(Libro libro) {
        abrirDB();
        try {
            db.store(libro);
            db.commit();
            System.out.println("✅ Libro guardado: " + libro);
        } finally {
            cerrarDB();
        }
    }
    
    // Guardar autor
    public static void guardarAutor(Autor autor) {
        abrirDB();
        try {
            db.store(autor);
            db.commit();
            System.out.println("✅ Autor guardado: " + autor);
        } finally {
            cerrarDB();
        }
    }
    
    // Listar todos los libros
    public static void listarLibros() {
        abrirDB();
        try {
            List<Libro> libros = db.query(Libro.class);
            System.err.println("\n📚 Libros en la biblioteca:");
            for (Libro l : libros) {
                System.out.println(l);
            }
        } finally {
            cerrarDB();
        }
    }
    
    // Listar todos los autores
    public static void listarAutores() {
        abrirDB();
        try {
            List<Autor> autores = db.query(Autor.class);
            System.err.println("\n🖊 Autores en la biblioteca:");
            for (Autor a : autores) {
                System.out.println(a);
            }
        } finally {
            cerrarDB();
        }
    }
    
    // Buscar libros por autor
    public static void buscarLibrosPorAutor(String nombreAutor) {
        abrirDB();
        try {
            Query query = db.query();
            query.constrain(Libro.class);
            query.descend("autor").constrain(nombreAutor);
            List<Libro> resultado = query.execute();
            System.out.println("\n🔍 Libros de " + nombreAutor + ":");
            for (Libro l : resultado) {
                System.out.println(l);
            }
        } finally {
            cerrarDB();
        }
    }
    
    // Actualizar información de un libro (por título)
    public static void actualizarLibro(String titulo, String nuevoGenero) {
        abrirDB();
        try {
            Query query = db.query();
            query.constrain(Libro.class);
            query.descend("titulo").constrain(titulo);
            List<Libro> resultado = query.execute();

            if (!resultado.isEmpty()) {
                Libro l = resultado.get(0);
                l.setGenero(nuevoGenero);
                db.store(l);
                db.commit();
                System.out.println("✅ Libro actualizado: " + l);
            } else {
                System.out.println("⚠ No se encontró el libro.");
            }
        } finally {
            cerrarDB();
        }
    }
    
    // Eliminar un libro (por título)
    public static void eliminarLibro(String titulo) {
        abrirDB();
        try {
            Query query = db.query();
            query.constrain(Libro.class);
            query.descend("titulo").constrain(titulo);
            List<Libro> resultado = query.execute();

            if (!resultado.isEmpty()) {
                db.delete(resultado.get(0));
                db.commit();
                System.out.println("🗑 Libro eliminado: " + titulo);
            } else {
                System.out.println("⚠ No se encontró el libro.");
            }
        } finally {
            cerrarDB();
        }
    }
}
